package com.transactions.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}

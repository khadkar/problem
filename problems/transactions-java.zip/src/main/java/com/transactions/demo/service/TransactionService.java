package com.transactions.demo.service;

import java.util.List;
import java.util.Map;

public interface TransactionService {
	
	public List<Map<String,Object>> getTransactionData();
}

package com.transactions.demo.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transactions.demo.dao.TransactionDao;
import com.transactions.demo.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired
	TransactionDao transactionDao;

	@Override
	public List<Map<String, Object>> getTransactionData() {
		return transactionDao.getTransactionData();
	}

}

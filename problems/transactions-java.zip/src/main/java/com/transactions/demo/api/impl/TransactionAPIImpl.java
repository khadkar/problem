package com.transactions.demo.api.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transactions.demo.service.TransactionService;

@RestController
public class TransactionAPIImpl {

	@Autowired
	TransactionService transactionService;

	@GetMapping("/transactions")
	public List<Map<String, Object>> getTransactionData() {
		return transactionService.getTransactionData();
	}

}

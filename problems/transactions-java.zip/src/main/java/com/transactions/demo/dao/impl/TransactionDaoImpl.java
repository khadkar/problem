package com.transactions.demo.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.transactions.demo.dao.TransactionDao;

@Repository
public class TransactionDaoImpl implements TransactionDao {

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Value("${transactions.getTransactionDataQuery}")
	private String getTransactionDataQuery;

	@Override
	public List<Map<String, Object>> getTransactionData() {
		MapSqlParameterSource map = new MapSqlParameterSource();
		return namedParameterJdbcTemplate.queryForList(getTransactionDataQuery, map);
	}

}

import React from "react";
import ReactDOM from "react-dom";

class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      transactionData: [],
    };
  }

  componentDidMount() {
    fetch("http://localhost:4800/transactions")
      .then((response) => response.json())
      .then((data) => this.setState({ transactionData: data }));
  }

  render() {
    let transactionData = this.state.transactionData;
    return (
      <div className="ui container">
        <div className="ui header">
          <u>Transaction-Reward Points</u>
        </div>
        <div className="ui header">Name : {transactionData[0]?.name}</div>
        <div className="ui header">
          Total Reward Points : {this.getTotalPoints(transactionData)}
        </div>
        <div className="ui header">
          {this.getMonthTotal(transactionData).map((x) => {
            return <p key={x}>{x}</p>;
          })}
        </div>
        <div className="ui header">
          <u> 3 month Transactions</u>
        </div>
        <table className="ui celled table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Month</th>
              <th>Amount</th>
              <th>Details</th>
              <th>Reward Points</th>
            </tr>
          </thead>
          <tbody>
            {transactionData.map((t) => {
              return (
                <tr key={t.id}>
                  <td data-label="ID">{t.id}</td>
                  <td data-label="Date">{t.date}</td>
                  <td data-label="Month">{t.month}</td>
                  <td data-label="Amount">${t.amount}</td>
                  <td data-label="Details">
                    {this.getRewardPointDetails(t.amount)}
                  </td>
                  <td data-label="Reward Points">
                    {this.getRewardPoints(t.amount)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  getRewardPointDetails(amount) {
    let amountOver100 = amount - 100;
    let amountOver50 = amount >= 100 ? 50 : amount - 50;
    if (amountOver100 <= 0) {
      amountOver100 = 0;
    }
    if (amountOver50 <= 0) {
      amountOver50 = 0;
    }
    return `2 X ${amountOver100} + 1 X ${amountOver50} `;
  }

  getRewardPoints(amount) {
    let amountOver100 = amount - 100;
    let amountOver50 = amount >= 100 ? 50 : amount - 50;
    if (amountOver100 <= 0) {
      amountOver100 = 0;
    }
    if (amountOver50 <= 0) {
      amountOver50 = 0;
    }
    let rewardPoints = 0;
    rewardPoints += 2 * amountOver100;
    rewardPoints += amountOver50 * 1;
    return rewardPoints;
  }

  getMonthTotal(transactionData) {
    let months = new Set();
    transactionData.forEach((x) => {
      months.add(x.month);
    });

    let monthPoints = [];
    months.forEach((m) => {
      let total = 0;
      transactionData.forEach((t) => {
        if (m === t.month) {
          total += this.getRewardPoints(t.amount);
        }
      });
      monthPoints.push(m + " : " + total);
    });
    return monthPoints;
  }

  getTotalPoints(transactionData) {
    let total = 0;
    transactionData.forEach((t) => {
      total += this.getRewardPoints(t.amount);
    });
    return total;
  }
}

ReactDOM.render(<App />, document.getElementById("root"));
